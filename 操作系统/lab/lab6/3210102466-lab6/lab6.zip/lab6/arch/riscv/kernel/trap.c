// trap.c 
#include "clock.h"
#include "printk.h"
#include "proc.h"
#include "trap.h"
#include "types.h"
#include "defs.h"
#include "../user/syscall.h"
//extern struct task_struct* current;
extern struct task_struct* current;
extern char _sramdisk[];//uapp段
extern char _eramdisk[];
void do_page_fault(struct pt_regs *regs)
{
    //1. 通过 stval 获得访问出错的虚拟内存地址（Bad Address）
    uint64 bad_address = regs->stval;
    //2. 通过 find_vma() 查找 Bad Address 是否在某个 vma 中
    struct vm_area_struct *vma = find_vma(current, bad_address);
    if (vma != NULL)
    {
        // 3. 分配一个页，将这个页映射到对应的用户地址空间
        uint64 new_page = (uint64)kalloc();
        create_mapping((uint64 *)((uint64)current->pgd + PA2VA_OFFSET),
                       bad_address >> 12 << 12, new_page - PA2VA_OFFSET, PGSIZE, (vma->vm_flags) | 0x11);
        // 4. 通过 (vma->vm_flags & VM_ANONYM) 获得当前的 VMA 是否是匿名空间
        // 5. 根据 VMA 匿名与否决定将新的页清零或是拷贝 uapp 中的内容
        // 匿名，将新的页清零
        if (vma->vm_flags & VM_ANONYM)
        {
            new_page = 0;
        }
        // 非匿名，拷贝 uapp 中的内容
        else
        {
            char *uapp = (char *)(((uint64)_sramdisk + (bad_address - vma->vm_start)) >> 12 << 12);
            for (int i = 0; i < PGSIZE; i++)
            {
                (&new_page)[i] = uapp[i];
            }
        }
    }
    else
    {
        return;
    }
    
}

void trap_handler(uint64 scause, uint64 sepc, struct pt_regs *regs) 
{
    // 通过 `scause` 判断trap类型
    // 如果是interrupt 判断是否是timer interrupt
    // 如果是timer interrupt 则打印输出相关信息, 并通过 `clock_set_next_event()` 设置下一次时钟中断
    // `clock_set_next_event()` 见 4.3.4 节
    // 其他interrupt / exception 可以直接忽略

    // YOUR CODE HERE
    if (scause >> 63) // 最高位为1就是interrupt
    {
        unsigned long rest = scause - 0x8000000000000000;
        if (rest == 5)// 剩余位表示5时是timer interrupt
        { 
            //printk("\nkernel is running!\n[S] Supervisor Mode Timer Interrupt\n");
            clock_set_next_event();
            //lab2
            do_timer();
        }
    }
    //ECALL_FROM_U_MODE exception
    else if(scause==0x8)
    {
        syscall(regs);
    }

    else if(scause==12||scause==13||scause==15)
    {
        do_page_fault(regs);
    }
    else 
    {
        printk("[S] Unhandled trap, ");
        printk("scause: %lx, ", scause);
        printk("stval: %lx, ", regs->stval);
        printk("sepc: %lx\n", regs->sepc);
        while (1);
    }
}