// arch/riscv/kernel/proc.c
#include "proc.h"
#include "mm.h"
#include "defs.h"
#include "rand.h"
#include "printk.h"
#include "test.h"
#include "vm.h"
#include "elf.h"

// arch/riscv/kernel/proc.c

extern void __dummy();
extern void __switch_to(struct task_struct *prev, struct task_struct *next);

struct task_struct *idle;           // idle process
struct task_struct *current;        // 指向当前运行线程的 `task_struct`
struct task_struct *task[NR_TASKS]; // 线程数组, 所有的线程都保存在此

/**
 * new content for unit test of 2023 OS lab2
 */
extern uint64 task_test_priority[]; // test_init 后, 用于初始化 task[i].priority 的数组
extern uint64 task_test_counter[];  // test_init 后, 用于初始化 task[i].counter  的数组

extern unsigned long swapper_pg_dir[512] __attribute__((__aligned__(0x1000)));
extern char _sramdisk[]; // uapp段
extern char _eramdisk[];

void do_mmap(struct task_struct *task, uint64_t addr, uint64_t length, uint64_t flags,
             uint64_t vm_content_offset_in_file, uint64_t vm_content_size_in_file)
{
    task->vma_cnt++;
    struct vm_area_struct *vma = &(task->vmas[task->vma_cnt]);
    vma->vm_start = addr;
    vma->vm_end = addr + length;
    vma->vm_flags = flags;
    vma->vm_content_offset_in_file = vm_content_offset_in_file;
    vma->vm_content_size_in_file = vm_content_size_in_file;
}

struct vm_area_struct *find_vma(struct task_struct *task, uint64_t addr)
{
    for (int i = 0; i < task->vma_cnt; i++)
    {
        if (addr <= task->vmas[i].vm_end)
        {
            return &(task->vmas[i]);
        }
    }
    return NULL;
}

void task_init()
{
    printk("task_init\n");
    // test_init(NR_TASKS);
    //  1. 调用 kalloc() 为 idle 分配一个物理页
    //  2. 设置 state 为 TASK_RUNNING;
    //  3. 由于 idle 不参与调度 可以将其 counter / priority 设置为 0
    //  4. 设置 idle 的 pid 为 0
    //  5. 将 current 和 task[0] 指向 idle

    /* YOUR CODE HERE */
    uint64 idlePage = kalloc();
    idle = (struct task_struct *)idlePage;
    idle->state = TASK_RUNNING;
    idle->counter = 0;
    idle->priority = 0;
    idle->pid = 0;
    current = idle;
    task[0] = idle;
    // 1. 参考 idle 的设置, 为 task[1] ~ task[NR_TASKS - 1] 进行初始化
    // 2. 其中每个线程的 state 为 TASK_RUNNING, 此外，为了单元测试的需要，counter 和 priority 进行如下赋值：
    //      task[i].counter  = task_test_counter[i];
    //      task[i].priority = task_test_priority[i];
    // 3. 为 task[1] ~ task[NR_TASKS - 1] 设置 `thread_struct` 中的 `ra` 和 `sp`,
    // 4. 其中 `ra` 设置为 __dummy （见 4.3.2）的地址,  `sp` 设置为 该线程申请的物理页的高地址

    /* YOUR CODE HERE */
    int i = 1;
    uint64 taskPage = kalloc();
    task[i] = (struct task_struct *)taskPage;
    task[i]->state = TASK_RUNNING;
    task[i]->counter = 0;
    task[i]->priority = rand();
    task[i]->pid = i;
    task[i]->thread.ra = (uint64)__dummy;
    task[i]->thread.sp = (uint64)task[i] + PGSIZE;

    // 每个用户态进程都分配单独的页表
    task[i]->pgd = (uint64 *)alloc_page();
    // 将内核页表 （ swapper_pg_dir ） 复制到每个进程的页表中。
    for (int j = 0; j < 512; j++)
    {
        task[i]->pgd[j] = swapper_pg_dir[j];
    }

    Elf64_Ehdr *ehdr = (Elf64_Ehdr *)_sramdisk;

    uint64_t phdr_start = (uint64_t)ehdr + ehdr->e_phoff;
    int phdr_cnt = ehdr->e_phnum;

    Elf64_Phdr *phdr;
    int load_phdr_cnt = 0;
    for (int i = 0; i < phdr_cnt; i++)
    {
        phdr = (Elf64_Phdr *)(phdr_start + sizeof(Elf64_Phdr) * i);
        if (phdr->p_type == PT_LOAD)
        {
            do_mmap(task, phdr->p_vaddr, phdr->p_memsz, ((phdr->p_flags) << 1), phdr->p_offset, phdr->p_filesz);
        }
    }
    // 用户栈：范围为 [USER_END - PGSIZE, USER_END) ，权限为 VM_READ | VM_WRITE, 并且是匿名的区域
    do_mmap(task, USER_END - PGSIZE, PGSIZE, VM_R_MASK | VM_W_MASK | VM_ANONYM, 0, 0);
    // 初始化我们刚刚在 thread_struct 中添加的三个变量
    task[i]->thread.sepc = task[i]->thread.sepc = ehdr->e_entry;
    ;
    uint64 sstatus = csr_read(sstatus);
    task[i]->thread.sstatus = sstatus & ~(0x100) | 0x40020; // spp[8]=0   spie[5]=1  sum[18]=1
    task[i]->thread.sscratch = USER_END;
    task[i]->pgd = (unsigned long)task[i]->pgd - PA2VA_OFFSET;

    // 将 uapp 所在的页面映射到每个进行的页表中
    // create_mapping(task[i]->pgd, USER_START, (uint64)_sramdisk-PA2VA_OFFSET, (uint64)_eramdisk-(uint64)_sramdisk, 0b11111);
    // 申请用户态栈,放在user space 的最后一个页面
    //  uint64 u_mode_stack = alloc_page();
    //  create_mapping(task[i]->pgd, USER_END-PGSIZE, u_mode_stack - PA2VA_OFFSET, PGSIZE, 0b11111);
    //  task[i]->pgd=task[i]->pgd-PA2VA_OFFSET;

    for (int i = 2; i < NR_TASKS; i++)
    {
        task[i] = NULL;
    }

    printk("...proc_init done!\n");
}

// arch/riscv/kernel/proc.c
void dummy()
{
    printk("dummy\n");
    // schedule_test();
    uint64 MOD = 1000000007;
    uint64 auto_inc_local_var = 0;
    int last_counter = -1;
    while (1)
    {
        if ((last_counter == -1 || current->counter != last_counter) && current->counter != 0)
        {
            if (current->counter == 1)
            {
                --(current->counter); // forced the counter to be zero if this thread is going to be scheduled
            }                         // in case that the new counter is also 1, leading the information not printed.
            last_counter = current->counter;
            auto_inc_local_var = (auto_inc_local_var + 1) % MOD;
            printk("[PID = %d] is running. auto_inc_local_var = %d\n", current->pid, auto_inc_local_var);
        }
    }
    // printk("\n");
}

void switch_to(struct task_struct *next)
{
    if (next != current)
    {
        // printk("1");
        struct task_struct *prev = current;
        // printk("2");
        current = next;
        // printk("3");
        __switch_to(prev, next);
        // printk("4");
        return;
    }
    else
    {
        return;
    }
    // printk("\nswitch_to end\n");
}

void do_timer(void)
{
    // 1. 如果当前线程是 idle 线程 直接进行调度
    // 2. 如果当前线程不是 idle 对当前线程的运行剩余时间减1 若剩余时间仍然大于0 则直接返回 否则进行调度

    /* YOUR CODE HERE */
    if (current == idle)
    {
        schedule();
    }
    else
    {
        if (current->counter > 0)
        {
            current->counter--;
        }
        if (current->counter == 0)
        {
            schedule();
        }
    }
}

#ifdef DSJF
void schedule(void)
{
    /* YOUR CODE HERE */
    // printk("schedule\n");
    int min_counter = 0xFFFFFFFF;
    struct task_struct *next;
    int all0 = 1;
    for (int i = 1; i < NR_TASKS; i++)
    {
        if (task[i]->state == TASK_RUNNING && task[i]->counter != 0)
        {
            all0 = 0;
            if (task[i]->counter < min_counter)
            {
                min_counter = task[i]->counter;
                next = task[i];
            }
        }
    }

    if (all0)
    {
        printk("\n");
        for (int i = 1; i < NR_TASKS; i++)
        {
            task[i]->counter = rand();
            printk("SET [PID = %d COUNTER = %d]\n", task[i]->pid, task[i]->counter);
        }
        schedule();
    }
    else
    {
        if (next)
        {
            printk("\n\nswitch to [PID = %d COUNTER = %d]\n\n", next->pid, next->counter);
            switch_to(next);
        }
    }
    // printk("\nall0 = %d\n\n", all0);
    // printk("\nmin_counter = %d\n\n", min_counter);
}

#else

void schedule(void)
{
    /* YOUR CODE HERE */
    // int max_p = 0;
    // struct task_struct *next;
    // int all0 = 1;
    // for (int i = 1; i < NR_TASKS; i++)
    // {
    //     if (task[i]->state == TASK_RUNNING && task[i]->counter != 0 && task[i]->priority != 0)
    //     {
    //         all0 = 0;
    //         if (task[i]->priority > max_p)
    //         {
    //             max_p = task[i]->priority;
    //             next = task[i];
    //         }
    //     }
    // }

    // if (all0)
    // {
    //     printk("\n");
    //     for (int i = 1; i < NR_TASKS; i++)
    //     {
    //         task[i]->counter = rand();
    //         task[i]->priority = rand();
    //         printk("SET [PID = %d PRIORITY = %d COUNTER = %d]\n", task[i]->pid, task[i]->priority, task[i]->counter);
    //     }
    //     schedule();
    // }
    // else
    // {
    //     if (next)
    //     {
    //         printk("\n\nswitch to [PID = %d PRIORITY = %d COUNTER = %d]\n\n", next->pid, next->priority, next->counter);
    //         switch_to(next);
    //     }
    // }

    int max = 0;
    struct task_struct *next;
    int all0 = 1;
    for (int i = NR_TASKS - 1; i > 0; i--)
    {
        if (task[i]->state == TASK_RUNNING && task[i]->counter != 0)
        {
            all0 = 0;
            if (task[i]->counter > max)
            {
                max = task[i]->counter;
                next = task[i];
            }
        }
    }

    if (all0)
    {
        printk("\n");
        for (int i = NR_TASKS - 1; i > 0; i--)
        {
            task[i]->counter = (task[i]->counter >> 1) + task[i]->priority;
            // task[i]->priority = rand();
            printk("SET [PID = %d PRIORITY = %d COUNTER = %d]\n", task[i]->pid, task[i]->priority, task[i]->counter);
        }
        schedule();
    }
    else
    {
        if (next)
        {
            printk("\n\nswitch to [PID = %d PRIORITY = %d COUNTER = %d]\n\n", next->pid, next->priority, next->counter);
            switch_to(next);
        }
    }

    // int c = -1;
    // int next = 0;
    // int i = NR_TASKS;
    // while (1) {
    // 	struct task_struct **p = &task[NR_TASKS];
    // 	while (--i) {
    // 		if (!*--p)
    // 			continue;
    // 		if ((*p)->state == TASK_RUNNING && (*p)->counter > c)
    // 			c = (*p)->counter, next = i;
    // 	}
    // 	if (c) break;
    // 	for(p = &task[NR_TASKS] ; p > &task[0] ; --p)
    // 		if (*p)
    // 			(*p)->counter = ((*p)->counter >> 1) +
    // 					(*p)->priority;
    // }
    // switch_to(task[next]);
}
#endif