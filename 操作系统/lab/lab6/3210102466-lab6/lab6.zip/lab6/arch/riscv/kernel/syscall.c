#include "../user/syscall.h"
#include"proc.h"
#include "printk.h"
#include"defs.h"
extern struct task_struct* current;
extern void __ret_from_fork();
extern void create_mapping(uint64 *pgtbl, uint64 va, uint64 pa, uint64 sz, int perm);
extern struct task_struct* task[NR_TASKS];
extern unsigned long  swapper_pg_dir[512] __attribute__((__aligned__(0x1000)));
extern char _sramdisk[];//uapp段
extern char _eramdisk[];
void syscall(struct pt_regs* regs)
{
    //64 号系统调用sys_write
    if(regs->a7==SYS_WRITE)
    {
        sys_write(regs->a0, (const char*)regs->a1, regs->a2);
        regs->sepc+=4;
    }
    //172 号系统调用 sys_getpid() 该调用从current中获取当前的pid放入a0中返回
    else if(regs->a7==SYS_GETPID)
    {
        regs->a0=sys_getpid();
        regs->sepc+=4;
    }
    else if(regs->a7==SYS_CLONE)
    {
        regs->a0=sys_clone(regs);
        regs->sepc+=4;
    }
    else
    {
        printk("[S] Unhandled syscall: %lx", regs->a7);
        while (1);
    }
}

void sys_write(unsigned int fd, const char* buf, int count) 
{
    for (int i = 0; i < count; i++)
    {
        if(fd==1)
        {
            printk("%c", buf[i]);
        }
    }
}

unsigned long sys_getpid() 
{
    return current->pid;
}

unsigned long sys_clone(struct pt_regs *regs) {
    /*
     1. 参考 task_init 创建一个新的 task，将的 parent task 的整个页复制到新创建的 
        task_struct 页上(这一步复制了哪些东西?）。将 thread.ra 设置为 
        __ret_from_fork，并正确设置 thread.sp
        (仔细想想，这个应该设置成什么值?可以根据 child task 的返回路径来倒推)

     2. 利用参数 regs 来计算出 child task 的对应的 pt_regs 的地址，
        并将其中的 a0, sp, sepc 设置成正确的值(为什么还要设置 sp?)

     3. 为 child task 申请 user stack，并将 parent task 的 user stack 
        数据复制到其中。 (既然 user stack 也在 vma 中，这一步也可以直接在 5 中做，无需特殊处理)

     4. 为 child task 分配一个根页表，并仿照 setup_vm_final 来创建内核空间的映射

     5. 根据 parent task 的页表和 vma 来分配并拷贝 child task 在用户态会用到的内存

     6. 返回子 task 的 pid
    */
    int pid = 2;
    //找到一个空闲进程
    while (task[pid] != NULL)
    {
        pid++;
        if (pid >= NR_TASKS)
        {
            return -1;
        }
    }
    //进程内容复制
    //复制父进程页面内容
    task[pid] = (struct task_struct *)kalloc();
    char *child = (char *)task[pid];
    char *parent = (char *)(current);
    for (int i = 0; i < PGSIZE; i++)
    {
        child[i] = parent[i];
    }
    //复制父进程结构体
    task[pid]->state = TASK_RUNNING;
    task[pid]->counter = 0;
    task[pid]->priority = rand();
    task[pid]->pid = pid;
    task[pid]->thread.ra = (uint64)(__ret_from_fork);
    task[pid]->thread.sp = (uint64)task[pid] + PGSIZE;
    task[pid]->thread.sepc = regs->sepc + 4;
    task[pid]->thread.sscratch = regs->sscratch;
    task[pid]->thread.sstatus = regs->sstatus;
    //设置寄存器
    struct pt_regs *child_regs = (struct pt_regs *)kalloc();
    child_regs=(struct pt_regs*)(task[pid]->thread.sp);
    child_regs->a0 = 0;//子进程的返回值为0
    uint64 sscratch = csr_read(sscratch);
    child_regs->sp = sscratch;//用户栈在trap里和内核栈交换了
    child_regs->sepc = regs->sepc + 4;
    //复制内核页表
    task[pid]->pgd = (unsigned long *)kalloc();
    for (int i = 0; i < 512; i++)
    {
        task[pid]->pgd[i] = swapper_pg_dir[i];
    }
    // 复制父进程的用户栈
    unsigned long user_stack = kalloc();
    create_mapping(task[pid]->pgd, USER_START, user_stack - PA2VA_OFFSET, PGSIZE, 0x1f);
    char *child_stack = (char *)(user_stack);
    char *parent_stack = (char *)(((regs->sscratch) >> 12 << 12));
    for (int i = 0; i < PGSIZE; i++)
    {
        child_stack[i] = parent_stack[i];
    }
    //设置子进程的VMA
    for (int i = 0; i < current->vma_cnt; i++)
    {
        struct vm_area_struct *vma = &(current->vmas[i]);
        do_mmap(task[i]->vmas, vma->vm_start, vma->vm_end - vma->vm_start, vma->vm_flags,
                vma->vm_content_offset_in_file, vma->vm_content_size_in_file);
    }
    task[pid]->pgd = (unsigned long)task[pid]->pgd - PA2VA_OFFSET;

    return pid;
}