#include "printk.h"
#include "sbi.h"
#include "defs.h"
#include "test.h"
#include "proc.h"
extern void test();
extern char _stext[];
extern char _srodata[];

int start_kernel() {
    printk("2022");
    printk(" Hello RISC-V\n");
    
    schedule();

    test(); // DO NOT DELETE !!!

	return 0;
}
