#include "../user/syscall.h"
#include"proc.h"
#include "printk.h"
extern struct task_struct* current;
void syscall(struct pt_regs* regs)
{
    //64 号系统调用sys_write
    if(regs->a7==SYS_WRITE)
    {
        sys_write(regs->a0, (const char*)regs->a1, regs->a2);
        regs->sepc+=4;
    }
    //172 号系统调用 sys_getpid() 该调用从current中获取当前的pid放入a0中返回
    else if(regs->a7==SYS_GETPID)
    {
        regs->a0=sys_getpid();
        regs->sepc+=4;
    }
    else
    {
        printk("[S] Unhandled syscall: %lx", regs->a7);
        while (1);
    }
}

void sys_write(unsigned int fd, const char* buf, int count) 
{
    for (int i = 0; i < count; i++)
    {
        if(fd==1)
        {
            printk("%c", buf[i]);
        }
    }
}

unsigned sys_getpid() 
{
    return current->pid;
}